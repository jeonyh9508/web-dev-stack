import React from "react";
function MainComp() {
  // 로그인 성공시 이동할 컴포넌트
  return (
    <div>
      <div>Main</div>
    </div>
  );
}
export default MainComp;

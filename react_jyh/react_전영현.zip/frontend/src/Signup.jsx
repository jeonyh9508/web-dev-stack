import React, { useState } from "react";
import { Link } from "react-router-dom";
import LoginValidation from "./LoginValidation";
import axios from "axios";

function Signup() {
  const [values, setValues] = useState({
    name: "",
    email: "",
    password: "",
  });
  const [errors, setErrors] = useState();

  const handleSubmit = (e) => {
    // 새로고침 방지
    e.preventDefault();
    // 회원가입 유효성 검사
    setErrors(LoginValidation(values));

    // 서버에 입력 데이터 전송
    axios.post("http://localhost:3000/signup", values).then((res) => {
      console.log(res.data);
      alert("가입 성공");
      window.location.href = "/";
    });
  };

  const handleInput = (e) => {
    // input 값이 변경(onChange)되면 기존 values에 덮어 씌우기 -> setValues
    setValues({ ...values, [e.target.name]: [e.target.value] });
  };
  return (
    <div className="d-flex justify-content-center align-items-center bg-dark vh-100">
      <div className="bg-white p-3 rounded w-25">
        <h2>Sign-Up</h2>

        <form action="" onSubmit={handleSubmit}>
          <div className="mb-3">
            <label>Name</label>
            <input
              placeholder="enter name"
              name="name"
              onChange={handleInput}
            />
          </div>

          <div className="mb-3">
            <label>Email</label>
            <input
              placeholder="enter email"
              name="email"
              onChange={handleInput}
            />
          </div>

          <div className="mb-3">
            <label>Password</label>
            <input
              type="password"
              placeholder="enter password"
              name="password"
              onChange={handleInput}
            />
          </div>

          <button type="submit" className="btn btn-success">
            가입완료
          </button>

          <p>계정이 없으신가요??</p>
          <Link to="/" className="btn btn-default border">
            로그인
          </Link>
        </form>
      </div>
    </div>
  );
}
export default Signup;
